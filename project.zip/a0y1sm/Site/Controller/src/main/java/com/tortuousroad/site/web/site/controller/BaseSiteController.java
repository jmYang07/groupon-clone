package com.tortuousroad.site.web.site.controller;

import com.tortuousroad.site.web.base.controller.FrontendBaseController;

public class BaseSiteController extends FrontendBaseController {


}