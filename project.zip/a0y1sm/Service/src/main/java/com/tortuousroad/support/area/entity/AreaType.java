package com.tortuousroad.support.area.entity;

/**
 * 地区类型
 */
public enum AreaType {

    PROVINCE,//省
    CITY//市

}
