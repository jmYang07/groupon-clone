package com.tortuousroad.admin.base.router;

/**
 * Router工具类
 */
public class RouterUtil {
}
