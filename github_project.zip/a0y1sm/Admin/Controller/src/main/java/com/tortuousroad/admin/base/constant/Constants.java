package com.tortuousroad.admin.base.constant;

/**
 * 常量
 */
public class Constants {

//	public static final String IMAGE_DOMAIN = "http://img.tortuousroad.com";

	//FIXME 这里修改图片URL
	/**
	 * 图片域名
	 */
	public static final String IMAGE_DOMAIN = "http://127.0.0.1:9000";

}
