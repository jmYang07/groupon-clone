package com.tortuousroad.support.timer;

/**
 * 站内消息定时器
 */
public class MessageTimer {



}
