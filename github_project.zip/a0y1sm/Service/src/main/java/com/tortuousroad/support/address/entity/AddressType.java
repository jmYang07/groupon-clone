package com.tortuousroad.support.address.entity;

/**
 * 地址类型
 */
public enum AddressType {

    HOME,//家
    COMPANY,//公司
    OTHER

}
